# Sniffpad on Vercel

Live public URL: https://sniffpad.vercel.app

Production project: sniffpad, in mini-whales-projects. Next.js 16 with private Vercel Blob storage. The public HTML interface is in public/desk. API routes are in app/api.

## Sign-in
Sign-in uses an EVM wallet message signature. Short-lived, browser-bound challenges are consumed once using conditional private-storage deletes. Sessions use opaque random IDs in secure HttpOnly cookies and are revoked server-side on sign-out. Trails belong to the recovered wallet address. No transactions or spending approvals are requested. The original local Sites preview used simulated ChatGPT authentication; production does not.

## Configuration
Vercel provisions the private storage credential on the connected project. Do not commit or share local environment files. Optional MEMBERSHIP_TOKEN_ADDRESS and MEMBERSHIP_MIN_BALANCE enable token access only after the contract and raw-unit holding threshold are decided. Neither is configured: the proposed token has not launched.

## Development
Install dependencies with npm install, configure private storage through your Vercel account, then use npm run dev. Build with npm run build. The deployed production version passed 22 API integration checks covering wallet signatures, browser binding, replay prevention, private persistence, account isolation, concurrent saves, sign-out revocation, provider lookups and disabled token access. Tests use ephemeral, unfunded keys and send no blockchain transactions.

The Sites source in outputs/fieldnote is the prior host version. This archive contains the Vercel application source.
