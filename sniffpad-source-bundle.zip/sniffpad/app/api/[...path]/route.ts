import {recoverMessageAddress} from 'viem';
import {read,write,remove,conflict} from '../../../lib/storage';
import {session,createSession,destroySession,cookie,cookieHeader,cookieName,challengeCookie,random,hash} from '../../../lib/session';
export const runtime='nodejs';export const dynamic='force-dynamic';
export const maxDuration=30;
const json=(data:unknown,status=200,headers:Record<string,string>={})=>Response.json(data,{status,headers:{'Cache-Control':'no-store',...headers}});
const address=/^0x[a-fA-F0-9]{40}$/;
function config(){const e=process.env;return {token:e.MEMBERSHIP_TOKEN_ADDRESS||'',min:e.MEMBERSHIP_MIN_BALANCE||''}}
async function rpc(method:string,params:unknown[]){const r=await fetch('https://rpc.mainnet.chain.robinhood.com',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params}),signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error('Chain service unavailable');const d=await r.json() as any;if(d.error)throw Error('Chain read failed');return d.result}
function validateCases(v:any){if(!Array.isArray(v)||v.length>200)throw Error('Expected up to 200 case files');const ids=new Set();for(const c of v){if(!c||typeof c.id!=='string'||c.id.length>100||ids.has(c.id)||typeof c.name!=='string'||c.name.length>100||typeof c.address!=='string'||(c.address&&!address.test(c.address))||typeof c.question!=='string'||c.question.length>2000||typeof c.notes!=='string'||c.notes.length>20000||!Array.isArray(c.evidence)||c.evidence.length>500)throw Error('Invalid case file');ids.add(c.id);for(const x of c.evidence){if(!x||['id','title','kind','note','url','date'].some(k=>typeof x[k]!=='string')||x.note.length>5000||x.title.length>200||x.url.length>2048)throw Error('Invalid evidence entry');let u;try{u=new URL(x.url)}catch{throw Error('Invalid source URL')}if(!['http:','https:'].includes(u.protocol))throw Error('Invalid source protocol')}}}
async function market(a:string){const r=await fetch('https://api.dexscreener.com/latest/dex/tokens/'+a,{signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error('Market provider unavailable ('+r.status+')');const d=await r.json() as any;return {address:a,fetchedAt:new Date().toISOString(),pairs:(d.pairs||[]).filter((p:any)=>p.chainId==='robinhood'&&p.baseToken?.address?.toLowerCase()===a.toLowerCase()).sort((a:any,b:any)=>(b.liquidity?.usd||0)-(a.liquidity?.usd||0))}}
async function membership(uid:string){const c=config();const row=await read('wallets/'+uid+'.json');const wallet=row?row.data.address:uid;if(!address.test(c.token)||!/^\d+$/.test(c.min)||BigInt(c.min)<=BigInt(0))return {configured:false,member:false,address:wallet,token:null};if(!wallet)return {configured:true,member:false,address:null,token:c.token};const result=await rpc('eth_call',[{to:c.token,data:'0x70a08231'+wallet.slice(2).padStart(64,'0')},'latest']);if(!/^0x[0-9a-fA-F]+$/.test(result))throw Error('Token balance could not be read');return {configured:true,member:BigInt(result)>=BigInt(c.min),address:wallet,token:c.token,balance:BigInt(result).toString(),minimum:c.min}}
async function challengeLimit(req:Request){const ip=req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'local';const path='limits/'+hash(ip)+'.json';for(let i=0;i<3;i++){const r=await read(path);const now=Date.now(),active=r&&r.data.reset>now;if(active&&r.data.count>=12)return false;try{await write(path,{count:active?r.data.count+1:1,reset:active?r.data.reset:now+900000},r?.etag);return true}catch(e){if(!conflict(e))throw e}}return false}
async function challenge(req:Request,u:URL,owner:string|null){
  const d=await req.json() as any;if(!address.test(d.address))return json({error:'Invalid wallet address'},400);
  if(!await challengeLimit(req))return json({error:'Too many sign-in requests. Try again in 15 minutes.'},429);
  const nonce=random(),binding=random(),expiry=Date.now()+300000;
  const message=`${u.host} wants you to sign in with your Ethereum account:\n${d.address}\n\n${owner?'Link this wallet to your Sniffpad research account.':'Sign in to Sniffpad to save your research.'} No transaction or spending approval.\n\nURI: ${u.origin}\nVersion: 1\nChain ID: 4663\nNonce: ${nonce}\nIssued At: ${new Date().toISOString()}\nExpiration Time: ${new Date(expiry).toISOString()}`;
  await write('challenges/'+hash(nonce)+'.json',{address:d.address.toLowerCase(),nonce,message,expires:expiry,owner,binding:hash(binding)});
  return json({nonce,message},200,{'Set-Cookie':cookieHeader(challengeCookie,binding,300)});
}
async function verify(req:Request,owner:string|null){
  const d=await req.json() as any;if(typeof d.nonce!=='string'||!/^[a-f0-9]{64}$/.test(d.nonce)||typeof d.signature!=='string'||!/^0x[0-9a-fA-F]{130}$/.test(d.signature))return json({error:'Invalid verification payload'},400);
  const path='challenges/'+hash(d.nonce)+'.json',r=await read(path);
  if(!r||r.data.expires<Date.now()||r.data.owner!==owner||r.data.binding!==hash(cookie(req,challengeCookie)))return json({error:'Challenge expired or already used. Start again.'},400);
  const recovered=await recoverMessageAddress({message:r.data.message,signature:d.signature});
  if(recovered.toLowerCase()!==r.data.address)return json({error:'Signature does not match wallet'},403);
  try{await remove(path,r.etag)}catch(e){if(conflict(e))return json({error:'Challenge already used'},400);throw e}
  if(owner){const p='wallets/'+owner+'.json',old=await read(p);await write(p,{address:r.data.address},old?.etag);return json(await membership(owner));}
  // Rotate the session ID after successful authentication; never trust browser identity headers.
  await destroySession(req);
  return json({ok:true},200,{'Set-Cookie':await createSession(r.data.address)});
}
async function handle(req:Request){try{
 const u=new URL(req.url),path=u.pathname.replace(/^\/api\//,'');
 if(req.method!=='GET'&&req.headers.get('origin')!==u.origin)return json({error:'Same-origin request required'},403);
 if(path==='auth/challenge'&&req.method==='POST')return await challenge(req,u,null);
 if(path==='auth/verify'&&req.method==='POST')return await verify(req,null);
 if(path==='auth/signout'&&req.method==='POST')return json({ok:true},200,{'Set-Cookie':await destroySession(req)});
 const user=await session(req);
 if(path==='session'&&req.method==='GET')return json({user:user?{name:user.address.slice(0,6)+'…'+user.address.slice(-4),id:user.userId}:null,chainId:4663,auth:'wallet'});
 if(path==='market'&&req.method==='GET'){const a=u.searchParams.get('address')||'';if(!address.test(a))return json({error:'Invalid token address'},400);return json(await market(a))}
 if(path==='repository'&&req.method==='GET'){const repo=u.searchParams.get('repo')||'';if(!/^[A-Za-z0-9_.-]{1,100}\/[A-Za-z0-9_.-]{1,100}$/.test(repo))return json({error:'Use owner/repository'},400);const r=await fetch('https://api.github.com/repos/'+repo,{headers:{'User-Agent':'SNIFFPAD','Accept':'application/vnd.github+json'},signal:AbortSignal.timeout(12000)});if(!r.ok)return json({error:'Repository unavailable or GitHub rate limit reached'},502);const d=await r.json();return json({name:d.full_name,url:d.html_url,description:d.description,stars:d.stargazers_count,forks:d.forks_count,created:d.created_at,pushed:d.pushed_at,archived:d.archived,fetchedAt:new Date().toISOString()})}
 if(!user)return json({error:'Sign in with your wallet to save research'},401);const uid=user.userId;
 if(path==='workspace'&&req.method==='GET'){const r=await read('workspaces/'+uid+'.json');return json(r?r.data:{cases:null,revision:0})}
 if(path==='workspace'&&req.method==='PUT'){const raw=await req.text();if(raw.length>1500000)return json({error:'Workspace is too large'},413);let data;try{data=JSON.parse(raw);validateCases(data.cases);if(!Number.isSafeInteger(data.revision)||data.revision<0)throw Error('Invalid revision')}catch(e){return json({error:(e as Error).message},400)}if(data.cases.length>3&&!(await membership(uid)).member)return json({error:'Token membership is required for more than three trails. Token access is not activated yet.'},403);const p='workspaces/'+uid+'.json',old=await read(p);if((old?.data.revision||0)!==data.revision)return json({error:'Your workspace changed in another tab. Reload before saving.'},409);try{await write(p,{cases:data.cases,revision:data.revision+1},old?.etag)}catch(e){if(conflict(e))return json({error:'Your workspace changed in another tab. Reload before saving.'},409);throw e}return json({revision:data.revision+1})}
 if(path==='membership'&&req.method==='GET')return json(await membership(uid));
 if(path==='wallet/challenge'&&req.method==='POST')return await challenge(req,u,uid);
 if(path==='wallet/verify'&&req.method==='POST')return await verify(req,uid);
 if(path==='wallet'&&req.method==='DELETE'){const p='wallets/'+uid+'.json',old=await read(p);await write(p,{address:null},old?.etag);return json({ok:true})}
 if(path==='compare'&&req.method==='POST'){const d=await req.json() as any;if(!Array.isArray(d.addresses)||d.addresses.length<2||d.addresses.length>8||d.addresses.some((a:any)=>typeof a!=='string'||!address.test(a)))return json({error:'Provide between two and eight token addresses'},400);if(d.addresses.length>2&&!(await membership(uid)).member)return json({error:'Member access required for more than two tokens'},403);const result=await Promise.allSettled(d.addresses.map(market));return json({results:result.map((r,i)=>r.status==='fulfilled'?r.value:{address:d.addresses[i],error:'Data service unavailable for this token'})})}
 return json({error:'Route not found'},404);
 }catch(e){console.error('SNIFFPAD API',e instanceof Error?e.message:'Unknown failure');return json({error:'Service unavailable. Your saved data has not been replaced. Please retry.'},503)}}
export const GET=handle;export const POST=handle;export const PUT=handle;export const DELETE=handle;
