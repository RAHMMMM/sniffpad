import type { Metadata } from 'next';

export const metadata:Metadata={title:'SNIFFPAD — Give it a sniff.',description:'Source-linked research, live market comparisons and token membership on Robinhood Chain.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
