import { redirect } from 'next/navigation';
export default function Home(){ redirect('/desk/index.html'); }
