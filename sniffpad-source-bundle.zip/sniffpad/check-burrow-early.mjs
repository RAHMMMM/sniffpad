import {encodeFunctionData,decodeFunctionResult,parseAbi} from 'viem';
import fs from 'node:fs/promises';
const rpc='https://rpc.mainnet.chain.robinhood.com',curve='0x0e4867da17cd62afd504a02b7193641407d1c177';
async function call(method,params){let r=await fetch(rpc,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params})});let j=await r.json();if(j.error)throw Error(JSON.stringify(j.error));return j.result;}
const start=89697104,t0=1792115005,abi=parseAbi(['function getReserves() view returns (uint256,uint256)','function realQuoteReserve() view returns (uint256)']);
let output=[];
for(const sec of [95,120,154]){
 let lo=start,hi=start+1600;
 while(lo<hi){let mid=Math.ceil((lo+hi)/2),b=await call('eth_getBlockByNumber',['0x'+mid.toString(16),false]);if(Number(BigInt(b.timestamp))<=t0+sec)lo=mid;else hi=mid-1;}
 let b=await call('eth_getBlockByNumber',['0x'+lo.toString(16),false]);let row={seconds:sec,block:lo,time:new Date(Number(BigInt(b.timestamp))*1000).toISOString()};
 for(const fn of ['getReserves','realQuoteReserve']){try{let raw=await call('eth_call',[{to:curve,data:encodeFunctionData({abi,functionName:fn})},'0x'+lo.toString(16)]);let v=decodeFunctionResult({abi,functionName:fn,data:raw});row[fn]=Array.isArray(v)?v.map(String):String(v);}catch(e){row[fn]=e.message;}}
 output.push(row);console.log(JSON.stringify(row));
}
await fs.writeFile('../burrow/early-historical-state.json',JSON.stringify(output,null,2));
