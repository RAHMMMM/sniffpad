import { createHash,randomBytes } from 'node:crypto';
import { read,write,remove } from './storage';
export const cookieName=process.env.NODE_ENV==='production'?'__Host-sniffpad':'sniffpad_session';
export const challengeCookie=process.env.NODE_ENV==='production'?'__Host-sniffpad-challenge':'sniffpad_challenge';
export const random=()=>randomBytes(32).toString('hex');
export const hash=(v:string)=>createHash('sha256').update(v).digest('hex');
export function cookie(req:Request,name:string){return req.headers.get('cookie')?.split(';').map(s=>s.trim()).find(s=>s.startsWith(name+'='))?.slice(name.length+1)||'';}
export function cookieHeader(name:string,value:string,age:number){return `${name}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${age}${process.env.NODE_ENV==='production'?'; Secure':''}`;}
export async function session(req:Request){const token=cookie(req,cookieName);if(!/^[a-f0-9]{64}$/.test(token))return null;const path='sessions/'+hash(token)+'.json',row=await read(path);if(!row||row.data.expires<Date.now())return null;return {...row.data,path,etag:row.etag};}
export async function createSession(address:string){const token=random(),expires=Date.now()+7*86400000;await write('sessions/'+hash(token)+'.json',{address,userId:address.toLowerCase(),expires});return cookieHeader(cookieName,token,7*86400);}
export async function destroySession(req:Request){const s=await session(req);if(s)await remove(s.path,s.etag);return cookieHeader(cookieName,'',0);}
