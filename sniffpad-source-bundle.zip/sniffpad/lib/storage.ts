import { get,put,del } from '@vercel/blob';
export async function read<T=any>(path:string):Promise<{data:T;etag:string}|null>{
  const r=await get(path,{access:'private',useCache:false});
  if(!r||r.statusCode!==200)return null;
  return {data:JSON.parse(await new Response(r.stream).text()),etag:r.blob.etag};
}
export async function write(path:string,data:unknown,etag?:string){return put(path,JSON.stringify(data),{access:'private',addRandomSuffix:false,allowOverwrite:!!etag,ifMatch:etag,contentType:'application/json',cacheControlMaxAge:0});}
export async function remove(path:string,etag?:string){return del(path,etag?{ifMatch:etag}:undefined);}
export function conflict(e:unknown){return e instanceof Error && /precondition|already exists|conflict/i.test(e.name+' '+e.message);}
