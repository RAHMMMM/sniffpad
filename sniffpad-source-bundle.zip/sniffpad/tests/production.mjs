import assert from 'node:assert/strict';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {generatePrivateKey,privateKeyToAccount} from 'viem/accounts';
const run=promisify(execFile),origin=process.env.TEST_ORIGIN||'https://sniffpad-kgafc1l4a-mini-whales-projects.vercel.app';
const cli='/private/tmp/sniffpad-npm-cache/_npx/323e1700ae881c51/node_modules/vercel/dist/index.js';
const config='/Users/abdulwaheedabdulramon/Documents/Codex/2026-10-15/hi-bro-so-i-need-your/work/vercel-cli';
async function request(path,{method='GET',body,cookie='',extra={}}={}){
 const args=[cli,'curl',path,'--deployment',origin,'--','-i','-sS','--request',method];
 const headers={'Origin':origin,...extra};if(body!==undefined)headers['Content-Type']='application/json';if(cookie)headers.Cookie=cookie;
 for(const [k,v]of Object.entries(headers))args.push('--header',k+': '+v);
 if(body!==undefined)args.push('--data',JSON.stringify(body));
 const {stdout}=await run(process.execPath,args,{env:{...process.env,NO_UPDATE_NOTIFIER:'1',XDG_DATA_HOME:'/Users/abdulwaheedabdulramon/Documents/Codex/2026-10-15/hi-bro-so-i-need-your/work/vercel-xdg'},maxBuffer:3000000});
 const blocks=stdout.split(/\r?\n\r?\n/);const head=blocks.shift(),raw=blocks.join('\n\n');
 const status=Number(head.match(/HTTP\/[^ ]+ (\d+)/)?.[1]);let data;try{data=JSON.parse(raw)}catch{throw Error('Non-JSON response '+status+' '+raw.slice(0,200))}
 const cookies=[...head.matchAll(/^set-cookie:\s*([^;\r\n]+)/gim)].map(m=>m[1]).join('; ');
 return {status,data,cookie:cookies};
}
let count=0;function check(value,expected,label){assert.equal(value,expected,label);console.log('PASS '+label);count++}
const a=privateKeyToAccount(generatePrivateKey()),b=privateKeyToAccount(generatePrivateKey());
check((await request('/api/session')).data.user,null,'anonymous session');
check((await request('/api/session',{extra:{'oai-authenticated-user-id':'forged','oai-authenticated-user-email':'fake@example.com'}})).data.user,null,'identity headers cannot forge login');
check((await request('/api/workspace')).status,401,'anonymous workspace denied');
check((await request('/api/auth/challenge',{method:'POST',body:{address:a.address},extra:{Origin:'https://evil.example'}})).status,403,'cross-origin challenge denied');
const c=await request('/api/auth/challenge',{method:'POST',body:{address:a.address}});check(c.status,200,'real private storage challenge');
const sig=await a.signMessage({message:c.data.message});
check((await request('/api/auth/verify',{method:'POST',body:{nonce:c.data.nonce,signature:sig}})).status,400,'challenge requires its browser cookie');
check((await request('/api/auth/verify',{method:'POST',body:{nonce:c.data.nonce,signature:await b.signMessage({message:c.data.message})},cookie:c.cookie})).status,403,'wrong wallet denied');
const login=await request('/api/auth/verify',{method:'POST',body:{nonce:c.data.nonce,signature:sig},cookie:c.cookie});check(login.status,200,'wallet signature signs in');const cookie=login.cookie;
check((await request('/api/auth/verify',{method:'POST',body:{nonce:c.data.nonce,signature:sig},cookie:c.cookie})).status,400,'signature challenge cannot replay');
check((await request('/api/session',{cookie})).data.user.id,a.address.toLowerCase(),'session belongs to recovered address');
const trail={id:crypto.randomUUID(),name:'Deployment verification',address:'',question:'Does private storage persist?',notes:'Disposable test account',evidence:[]};
check((await request('/api/workspace',{method:'PUT',cookie,body:{cases:[trail],revision:0}})).status,200,'save research to private storage');
check((await request('/api/workspace',{cookie})).data.cases[0].id,trail.id,'saved research read back');
check((await request('/api/workspace',{method:'PUT',cookie,body:{cases:[],revision:0}})).status,409,'stale revision rejected');
const concurrent=await Promise.all([request('/api/workspace',{method:'PUT',cookie,body:{cases:[trail],revision:1}}),request('/api/workspace',{method:'PUT',cookie,body:{cases:[trail],revision:1}})]);assert.deepEqual(concurrent.map(r=>r.status).sort(),[200,409]);console.log('PASS concurrent writes cannot overwrite');count++;
check((await request('/api/workspace',{method:'PUT',cookie,body:{cases:[1,2,3,4].map(i=>({...trail,id:String(i),example:true})),revision:2}})).status,403,'client cannot bypass token gate');
const c2=await request('/api/auth/challenge',{method:'POST',body:{address:b.address}}),l2=await request('/api/auth/verify',{method:'POST',cookie:c2.cookie,body:{nonce:c2.data.nonce,signature:await b.signMessage({message:c2.data.message})}});check(l2.status,200,'second wallet signs in');
check((await request('/api/workspace',{cookie:l2.cookie})).data.cases,null,'second account cannot see first account trails');
check((await request('/api/membership',{cookie})).data.configured,false,'unlaunched token remains disabled');
const market=await request('/api/market?address=0x87001b25b3862e8758a5372df84693f80aa8b417');check(market.status,200,'market provider responds');
check((await request('/api/repository?repo=vercel/next.js')).status,200,'original GitHub source responds');
check((await request('/api/auth/signout',{method:'POST',cookie,body:{}})).status,200,'sign-out revokes server session');
check((await request('/api/workspace',{cookie})).status,401,'old session cookie rejected after sign-out');
await request('/api/auth/signout',{method:'POST',cookie:l2.cookie,body:{}});
console.log(`${count} checks passed. Ephemeral wallets used; no blockchain transaction sent.`);
